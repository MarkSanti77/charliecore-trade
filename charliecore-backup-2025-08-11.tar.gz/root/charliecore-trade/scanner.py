# scanner.py — Varredura tática (refinado, compatível)
from __future__ import annotations
import os
from typing import Tuple, Dict, Any, Optional

from data import get_market_snapshot
from estrategia import avaliar_de_snapshot  # import legado removido
# -------------------------------------------------------------

SNAPSHOT_LIMIT = int(os.getenv("SNAPSHOT_LIMIT", "500"))
DEFAULT_INTERVALS = ["4h", "1h", "15m", "5m"]

def analisar_ativo(symbol: Optional[str] = None,
                   intervals: Optional[list[str]] = None) -> Tuple[str, Dict[str, Any]]:
    """
    Executa análise consolidada usando snapshot multi-timeframe.
    Retorna (mensagem_formatada, contexto_dict) prontos para o Discord.

    :param symbol: par a ser analisado (ex.: BTCUSDT). Se None, usa SYMBOL do .env.
    :param intervals: lista de timeframes. Se None, usa DEFAULT_INTERVALS.
    """
    symbol = (symbol or os.getenv("SYMBOL", "BTCUSDT")).upper()
    intervals = intervals or DEFAULT_INTERVALS

    snap = get_market_snapshot(symbol, intervals, limit=SNAPSHOT_LIMIT)
    msg, ctx = avaliar_de_snapshot(snap)
    ctx["symbol"] = symbol
    return msg, ctx

# ===== Compatibilidade com fluxo antigo (async) =====
async def analisar_ativos(simbolo=None, intervalo="5m"):
    """
    Compat: mantém a assinatura usada pelo sentinel antigo.
    Agora usa o fluxo novo e retorna dict apenas quando houver call autorizada.
    """
    if simbolo is None:
        return None

    msg, ctx = analisar_ativo(simbolo)

    print(f"\n🧐 Ativo Monitorado: {simbolo} | Intervalo: {intervalo}")
    print(f"   {msg}")

    # Heurística de decisão baseada no texto final (mantém compat)
    txt = msg.lower()
    if "entrada long autorizada" in txt or "entrada **long**" in txt:
        direcao = "LONG"
    elif "entrada short autorizada" in txt or "entrada **short**" in txt:
        direcao = "SHORT"
    else:
        direcao = None

    if direcao:
        return {
            "ativo": simbolo,
            "intervalo": intervalo,
            "mensagem": msg,
            "direcao": direcao,
            "contexto": ctx
        }
    return None
