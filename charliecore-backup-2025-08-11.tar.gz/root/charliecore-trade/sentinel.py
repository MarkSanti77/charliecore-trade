# sentinel.py — CharlieCore Sentinel v2.2 (concorrência + jitter + robustez)
from __future__ import annotations
import os, time, asyncio, traceback, random
from typing import List, Tuple
from scanner import analisar_ativo          # sync
from messages import send_discord_message   # anti-spam + formatação

# Config via .env
INTERVAL_SECONDS = int(os.getenv("INTERVAL_SECONDS", "900"))     # 15 min
ASSETS_ENV = os.getenv("ASSETS", "BTCUSDT,ETHUSDT,SOLUSDT,PEPEUSDT,DOGEUSDT")
ATIVOS: List[str] = [a.strip().upper() for a in ASSETS_ENV.split(",") if a.strip()]

# Suavização de carga
MAX_CONCURRENCY = int(os.getenv("MAX_CONCURRENCY", "3"))         # quantos ativos em paralelo
PER_ASSET_JITTER = float(os.getenv("PER_ASSET_JITTER", "0.7"))   # jitter (segundos) entre disparos
RETRY_ASSET_ERRORS = int(os.getenv("RETRY_ASSET_ERRORS", "1"))   # tentativas rápidas por ativo

sem = asyncio.Semaphore(MAX_CONCURRENCY)

async def _analisar_um(simbolo: str) -> Tuple[str, dict, str]:
    """
    Analisa um ativo com pequeno jitter e proteção de erros.
    Retorna (msg, ctx, erro_str) — erro_str vazio se ok.
    """
    await asyncio.sleep(random.random() * PER_ASSET_JITTER)  # jitter
    try:
        # analisar_ativo é sync; roda em thread para não travar o loop
        msg, ctx = await asyncio.to_thread(analisar_ativo, simbolo)
        return msg, ctx, ""
    except Exception as e:
        return "", {}, f"{type(e).__name__}: {e}"

async def _worker(simbolo: str) -> Tuple[str, dict, str]:
    for attempt in range(RETRY_ASSET_ERRORS + 1):
        async with sem:
            msg, ctx, err = await _analisar_um(simbolo)
        if not err:
            return msg, ctx, ""
        if attempt < RETRY_ASSET_ERRORS:
            await asyncio.sleep(0.8 * (attempt + 1))  # backoff curto
    return "", {}, err

async def sentinela():
    print("🛰️ CharlieCore Sentinel iniciado.")
    print(f"⏱️ Intervalo: {INTERVAL_SECONDS}s | 🎯 Ativos: {', '.join(ATIVOS)} | ⚙️ Conc: {MAX_CONCURRENCY}")

    while True:
        rodada_inicio = time.strftime("%Y-%m-%d %H:%M:%S")
        print(f"\n📡 Nova varredura — {rodada_inicio}")

        tasks = [asyncio.create_task(_worker(simbolo)) for simbolo in ATIVOS]
        total_calls = 0

        for simbolo, task in zip(ATIVOS, tasks):
            try:
                msg, ctx, err = await task
                if err:
                    print(f"❌ {simbolo}: {err}")
                    continue

                # Log local compacto
                cat5 = ctx.get('stages', {}).get('5m', {}).get('categoria', 'sem dado')
                print(f"🧐 {simbolo} → {cat5}\n{msg}\n")

                # Envia (anti-spam cuida das duplicadas)
                ok = send_discord_message(msg, ctx)
                if ok:
                    t = msg.lower()
                    if ("entrada long autorizada" in t) or ("entrada short autorizada" in t):
                        total_calls += 1
                else:
                    print(f"⚠️ Falha ao enviar Discord para {simbolo}.")
            except Exception:
                traceback.print_exc()
                print(f"❌ Erro inesperado ao processar {simbolo}")

        print(f"📊 Calls autorizadas nesta rodada: {total_calls}")
        await asyncio.sleep(INTERVAL_SECONDS)

if __name__ == "__main__":
    try:
        asyncio.run(sentinela())
    except KeyboardInterrupt:
        print("🛑 Execução interrompida manualmente.")
